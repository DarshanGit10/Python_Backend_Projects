-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 19, 2020 at 02:09 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `student`
--

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE IF NOT EXISTS `students` (
  `roll` int(10) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `contact` int(15) DEFAULT NULL,
  `dob` varchar(15) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`roll`, `name`, `email`, `gender`, `contact`, `dob`, `address`) VALUES
(2, 'Kavya', 'kavya@gmail.com', 'female', 70015475, '2205202', 'bakjaba jkgakjam ca\n'),
(1, 'Darshan', 'darshan@gmail.com', 'male', 25459223, '4525785', 'kgajkgagjbcbajk\n'),
(3, 'Mahesh', 'mahesh@gmail.com', 'male', 741125832, '0203144', 'ajkbajkbakj\n'),
(4, 'Pooja', 'pooja@gmail.com', 'female', 455875222, '10031998', 'ajjkgkan ,m nlajbj a\n'),
(5, 'Vandana', 'vandana@gmail.com', 'female', 4654613, '64641', 'bjskajvbajbakj\n'),
(6, 'Hemanth', 'hemanth@gmail.com', 'male', 22323262, '03565875', 'avhcvjhabjkajgkj babkjab\n');
